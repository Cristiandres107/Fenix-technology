<?php
include ('conexion.php');
$con= conexion();
$no_documento=$_GET['no_documento'];


$sql= "SELECT * FROM usuario WHERE no_documento='$no_documento'";
$query=mysqli_query($con,$sql);
$row= mysqli_fetch_array($query); 
?>

<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style_formularios.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"/>
    <title>Editar Usuarios</title>
    <link rel="shortcut icon" href="../images/logo.png">
</head>

<body>
    <div class="container-form sign-up">
        <form action="actualizar_usuario.php" method="POST" class="formulario">    
            <h2 class="create-account">Editar Usuario</h2> <br>
            <input type="hidden" name="id" value="<?php echo $row['id'] ?>"> 

            <div class="form-control">
            <label for="tipo_documento">Tipo de documento</label>
            <br> 

            <select class="select" name="tipo_documento">   
             <div>
             <?php
                $con= conexion();

                $select="SELECT * FROM tipo_documento";
                $consulta= mysqli_query($con,$select);
                while($rauw=mysqli_fetch_array($consulta)){
                    $nombredocumento=$rauw['nombre'];
                ?>
                    <option value="<?php echo $nombredocumento ?>"><?php echo $nombredocumento?></option>
                <?php
                }
               ?>
             </div>    
            </select>
            </div> 
            <br>
            
            <div class="form-control">
            <label for="no_documento">Número de documento</label>
            <input type="hippen" name="no_documento" placeholder="Ingrese su número de documento" value="<?php echo $row['no_documento'] ?>">
            </div>

            <div class="form-control">
            <label for="nombres">Nombres</label>
            <input type="text" name="nombres"  placeholder="Ingrese sus nombres" value="<?php echo $row['nombres'] ?>">
            </div>

            <div class="form-control">
            <label for="apellidos">Apellidos</label>
            <input type="text" name="apellidos" placeholder="Ingrese sus apellidos" value="<?php echo $row['apellidos'] ?>">
            </div>
            
            
            <div class="form-control">
            <label for="telefono">Teléfono de contacto</label>
            <input type="tel" name="telefono" placeholder="Ingrese su teléfono de contacto" value="<?php echo $row['telefono'] ?>">
            </div>
            
            <div class="form-control">
            <label for="email">Email</label>
            <input type="text" name="email" placeholder="Ingrese su email" value="<?php echo $row['email'] ?>">
            </div>
            
            <div class="form-control">
            <label for="contraseña">clave</label>
            <input type="text" name="password" placeholder="Ingrese su contraseña" value="<?php echo $row['password'] ?>">
            </div>
            
            
            <input type="submit" value="Actualizar Información">
        </form>
    </div>    
</body>

</html>