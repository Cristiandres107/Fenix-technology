<?php

function conexion(){
    $con = mysqli_connect('localhost', 'root', '', 'fenix_technology', '3306');
    if($con !== false){ 
        echo 'Conexion exitosa';
        return $con;
    }else{
        return 'Error de conexion';
    }
}

?>
