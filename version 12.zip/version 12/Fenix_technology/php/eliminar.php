<?php
include('conexion.php');
$con = conexion();

$no_documento = $_GET['no_documento'];

$sql = "DELETE FROM usuario WHERE no_documento='$no_documento'";
$query = mysqli_query($con, $sql);

if ($query) {
    Header('Location: ../htmljefe/usuarios.php');
}
;

?>