<?php
$Nombre_usuario=$_POST['Nombre_usuario'];
$password=$_POST['clave'];
$con=mysqli_connect("localhost","root", "", "fenix_technology") or die ("ERROR DE CONEXION");
$consulta="SELECT * FROM usuario WHERE usuario= '$Nombre_usuario' AND password= '$Clave'";
$resultado=mysqli_query ($con, $consulta);
$filas=mysqli_num_rows($resultado);
if($filas>0){
    // CODIGO PARA MANEJO DE SESIONES
	session_start();
	$_SESSION['usuario']=$Nombre_usuario;
	header("location:indexjefe.html");
    //TERMINA CONDIGO DE MANEJO DE SESIONES
	header("locationo:indexjefe.html");
}
else
{
	echo "Este usuario NO ESTA REGISTRADO";

}
mysqli_free_result($resultado);
?>