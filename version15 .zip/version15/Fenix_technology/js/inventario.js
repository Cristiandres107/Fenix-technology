$(document).ready(function () {
    var multipleCardCarouselDamas = document.querySelector("#carouselDamas");
    var multipleCardCarouselCaballeros = document.querySelector("#carouselCaballeros");

    if (window.matchMedia("(min-width: 576px)").matches) {
        var carouselDamas = new bootstrap.Carousel(multipleCardCarouselDamas, {
            interval: false,
            wrap: false
        });
        var carouselCaballeros = new bootstrap.Carousel(multipleCardCarouselCaballeros, {
            interval: false,
            wrap: false
        });

        var carouselWidthDamas = $(".carousel-inner", multipleCardCarouselDamas)[0].scrollWidth;
        var cardWidthDamas = $(".carousel-item", multipleCardCarouselDamas).width();
        var scrollPositionDamas = 0;

        var carouselWidthCaballeros = $(".carousel-inner", multipleCardCarouselCaballeros)[0].scrollWidth;
        var cardWidthCaballeros = $(".carousel-item", multipleCardCarouselCaballeros).width();
        var scrollPositionCaballeros = 0;

        $("#carouselDamas .carousel-control-next").on("click", function () {
            if (scrollPositionDamas < carouselWidthDamas - cardWidthDamas * 3) {
                scrollPositionDamas += cardWidthDamas;
                $("#carouselDamas .carousel-inner").animate(
                    { scrollLeft: scrollPositionDamas },
                    600
                );
            }
        });
        $("#carouselDamas .carousel-control-prev").on("click", function () {
            if (scrollPositionDamas > 1) {
                scrollPositionDamas -= cardWidthDamas;
                $("#carouselDamas .carousel-inner").animate(
                    { scrollLeft: scrollPositionDamas },
                    600
                );
            }
        });

        $("#carouselCaballeros .carousel-control-next").on("click", function () {
            if (scrollPositionCaballeros < carouselWidthCaballeros - cardWidthCaballeros * 3) {
                scrollPositionCaballeros += cardWidthCaballeros;
                $("#carouselCaballeros .carousel-inner").animate(
                    { scrollLeft: scrollPositionCaballeros },
                    600
                );
            }
        });
        $("#carouselCaballeros .carousel-control-prev").on("click", function () {
            if (scrollPositionCaballeros > 1) {
                scrollPositionCaballeros -= cardWidthCaballeros;
                $("#carouselCaballeros .carousel-inner").animate(
                    { scrollLeft: scrollPositionCaballeros },
                    600
                );
            }
        });
    } else {
        $(multipleCardCarouselDamas).addClass("slide");
        $(multipleCardCarouselCaballeros).addClass("slide");
    }
});

