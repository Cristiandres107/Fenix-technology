<?php

require_once("conexion.php");




if (isset($_POST['accion'])) {
    switch ($_POST['accion']) {
        //casos de registros
        case 'editar_registro':
            editar_registro();
            break;

        case 'eliminar_registro';
            eliminar_registro();

            break;

        case 'acceso_user';
            acceso_user();
            break;


    }

}

function editar_registro()
{
    $conexion = mysqli_connect("localhost", "root", "", "fenix_technology");
    extract($_POST);
    $consulta = "UPDATE usuario SET PK_fk_Id_tdoc = '$tdoc', Numero_documento = '$ndocumento',  Primer_nombre = '$primer_nombre', 
        Segundo_nombre = '$segundo_nombre', Primer_apellido = '$primer_apellido', Segundo_apellido = '$segundo_nombre', Telefono_contacto = '$telefono',
        Nombre_usuario = '$nombre_usuario', Email = '$email', 
		Clave ='$clave', Estado_usuario = '$Estado' WHERE Id_usuario = '$id' ";

    mysqli_query($conexion, $consulta);


    header('Location: ../html/indexjefe-usuarios.php');

}

function eliminar_registro()
{
    $conexion = mysqli_connect("localhost", "root", "", "fenix_technology");
    extract($_POST);
    $id = $_POST['Id_usuario'];
    $consulta = "DELETE FROM usuario WHERE Id_usuario= $id";

    mysqli_query($conexion, $consulta);


    header('Location: ../html/indexjefe-usuarios.php');

}

function acceso_user()
{
    $nombre_usuario = $_POST['Nombre_usuario'];
    $clave = $_POST['Clave'];
    session_start();
    $_SESSION['Nombre_usuario'] = $nombre_usuario;

    $conexion = mysqli_connect("localhost", "root", "", "fenix_technology");
    $consulta = "SELECT * FROM usuario WHERE Nombre_usuario='$nombre_usuario' AND Clave='$clave'";
    $resultado = mysqli_query($conexion, $consulta);
    $filas = mysqli_fetch_array($resultado);


    if ($filas['Estado_usuario'] == 1) { //admin

        header('Location: ../html/indexjefe-usuarios.php');

    } else if ($filas['Estado_usuario'] == 2) { //lector
        header('Location: ./html/inventariojefebodega.html');
    } else {

        header('Location: ../html/iniciosesion.php');
        session_destroy();

    }


}






