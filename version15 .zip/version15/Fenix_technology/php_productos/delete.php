<?php
include_once '../php_productos/conexion.php';

try {
    $con->beginTransaction(); // Inicia una transacción

    if (isset($_GET['id'])) {
        $id = (int)$_GET['id'];

        // Desactiva temporalmente las restricciones de clave externa
        $con->exec("SET foreign_key_checks = 0");

        // Elimina registros relacionados en la tabla detalle_reporte_pedido
        $delete_referencing_rows = $con->prepare('DELETE FROM detalle_reporte_pedido WHERE Pk_fk_idproducto = :id');
        $delete_referencing_rows->execute(array(':id' => $id));

        // Elimina el producto
        $delete_product = $con->prepare('DELETE FROM producto WHERE Id_producto = :id');
        $delete_product->execute(array(':id' => $id));

        // Reactiva las restricciones de clave externa
        $con->exec("SET foreign_key_checks = 1");

        $con->commit(); // Confirma la transacción
        header('Location: ../htmlbodeguero/adidascaballeros.php');
    } else {
        header('Location: ../htmlbodeguero/adidascaballeros.php');
    }
} catch (PDOException $e) {
    $con->rollBack(); // Revierte la transacción en caso de error
    echo "Error: " . $e->getMessage();
}
?>
