<?php

session_start();
error_reporting(0);

$validar = $_SESSION['Nombre_usuario'];

if ($validar == null || $validar = '') {

    header("Location: ../html/iniciosesion.php");
    die();



}



?>
<!DOCTYPE html>
<html lang="es-MX">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registros</title>

    <link rel="stylesheet" href="./css/es.css">
    <link rel="stylesheet" href="./css/styles.css">
</head>

<body id="page-top">


    <form action="validar.php" method="POST">
        <div id="login">
            <div class="container">
                <div id="login-row" class="row justify-content-center align-items-center">
                    <div id="login-column" class="col-md-6">
                        <div id="login-box" class="col-md-12">

                            <br>
                            <br>
                            <h3 class="text-center">Registro de nuevo usuario</h3>

                            <div class="form-group">
                                <label for="Tipo_documento" class="form-label">Tipo de documento*</label>
                                <input type="text" id="Tipo_documento" name="Tipo_documento" class="form-control"
                                    required>
                            </div>

                            <div class="form-group">
                                <label for="Numero_documento" class="form-label">Número de documento *</label>
                                <input type="text" id="Numero_documento" name="Numero_documento" class="form-control"
                                    required>
                            </div>

                            <div class="form-group">
                                <label for="Primer_nombre" class="form-label">Primer nombre *</label>
                                <input type="text" id="Primer_nombre" name="Primer_nombre" class="form-control"
                                    required>
                            </div>

                            <div class="form-group">
                                <label for="Segundo_nombre" class="form-label">Segundo nombre *</label>
                                <input type="text" id="Segundo_nombre" name="Segundo_nombre" class="form-control"
                                    required>
                            </div>

                            <div class="form-group">
                                <label for="Primer_apellido" class="form-label">Primer apellido *</label>
                                <input type="text" id="Primer_apellido" name="Primer_apellido" class="form-control"
                                    required>
                            </div>

                            <div class="form-group">
                                <label for="Segundo_apellido" class="form-label">Segundo apellido *</label>
                                <input type="text" id="Segundo_apellido" name="Segundo_apellido" class="form-control"
                                    required>
                            </div>


                            <div class="form-group">
                                <label for="Telefono_contacto" class="form-label">Telefono contacto *</label>
                                <input type="tel" id="Telefono_contacto" name="Telefono_contacto" class="form-control"
                                    required>

                            </div>

                            <div class="form-group">
                                <label for="Nombre_usuario">Nombre usuario *</label><br>
                                <input type="text" name="Nombre_usuario" id="Nombre_usuario" class="form-control"
                                    placeholder="">
                            </div>

                            <div class="form-group">
                                <label for="Email">Email:</label><br>
                                <input type="email" name="Email" id="Email" class="form-control" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="Clave">Clave:</label><br>
                                <input type="password" name="Clave" id="Clave" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="Estado_usuario" class="form-label">Estado usuario *</label>
                                <input type="number" id="Estado_usuario" name="Estado_usuario" class="form-control"
                                    placeholder="Escribe el rol, 1 admin, 2 lector..">

                            </div>


                            <br>

                            <div class="mb-3">

                                <input type="submit" value="Guardar" class="btn btn-success" name="registrar">
                                <a href="../html/indexjefe-usuarios.php" class="btn btn-danger">Cancelar</a>

                            </div>
                        </div>
                    </div>

    </form>
    </div>
    </div>
    </div>
    </div>
    </div>
    </form>
</body>

</html>