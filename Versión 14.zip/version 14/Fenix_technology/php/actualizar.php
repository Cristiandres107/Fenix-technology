<?php

session_start();
error_reporting(0);

$validar = $_SESSION['Nombre_usuario'];

if ($validar == null || $validar = '') {

    header("Location: ../html/iniciosesion.php");
    die();


}





$id = $_GET['Id_usuario'];
$conexion = mysqli_connect("localhost", "root", "", "fenix_technology");
$consulta = "SELECT * FROM usuario WHERE Id_usuario = $id";
$resultado = mysqli_query($conexion, $consulta);
$usuario = mysqli_fetch_assoc($resultado);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style_formularios.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <title>Editar Usuarios</title>
    <link rel="shortcut icon" href="../images/logo.png">
</head>

<body>
    <form action="funciones.php" method="POST">
        <div id="login">
            <div class="container">
                <div id="login-row" class="row justify-content-center align-items-center">
                    <div id="login-column" class="col-md-6">
                        <div id="login-box" class="col-md-12">

                            <br>
                            <br>
                            <h3 class="text-center">Editar usuario</h3>

                            <div class="form-group">
                                <label for="Número documento" class="form-label">Número documento</label>
                                <input type="text" id="Número documento" name="Número documento" class="form-control"
                                    value="<?php echo $usuario['Primer_nombre']; ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="nombre" class="form-label">Primer nombre</label>
                                <input type="text" id="nombre" name="Primer_nombre" class="form-control"
                                    value="<?php echo $usuario['Primer_nombre']; ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="nombre" class="form-label">Segundo nombre</label>
                                <input type="text" id="nombre" name="nombre" class="form-control"
                                    value="<?php echo $usuario['Segundo_nombre']; ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="nombre" class="form-label">Primer apellido</label>
                                <input type="text" id="nombre" name="nombre" class="form-control"
                                    value="<?php echo $usuario['Segundo_nombre']; ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="nombre" class="form-label">Segundo apellido</label>
                                <input type="text" id="nombre" name="nombre" class="form-control"
                                    value="<?php echo $usuario['Segundo_nombre']; ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="telefono" class="form-label">Telefono contacto *</label>
                                <input type="tel" id="telefono" name="telefono" class="form-control"
                                    value="<?php echo $usuario['telefono']; ?>" required>

                            </div>

                            <div class="form-group">
                                <label for="telefono" class="form-label">Nombre usuario *</label>
                                <input type="tel" id="Nombre_usuario" name="Nombre_usuario" class="form-control"
                                    value="<?php echo $usuario['Nombre_usuario']; ?>" required>

                                <div class="form-group">
                                    <label for="username">Email</label><br>
                                    <input type="Email" name="correo" id="Email" class="form-control" placeholder=""
                                        value="<?php echo $usuario['Email']; ?>">
                                </div>

                                <div class="form-group">
                                    <label for="password">Clave</label><br>
                                    <input type="password" name="Clave" id="Clave" class="form-control"
                                        value="<?php echo $usuario['Clave']; ?>" required>

                                </div>

                                <div class="form-group">
                                    <label for="Estado">Estado</label><br>
                                    <input type="password" name="Estado" id="Estado" class="form-control"
                                        value="<?php echo $usuario['Estado']; ?>" required>

                                </div>

                                <div class="form-group">
                                    <label for="rol" class="form-label">Rol de usuario *</label>
                                    <input type="number" id="rol" name="rol" class="form-control"
                                        placeholder="Escribe el rol, 1 admin, 2 jefebodega.."
                                        value="<?php echo $usuario['rol']; ?>" required>
                                    <input type="hidden" name="accion" value="editar_registro">
                                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                                </div>

                                <br>

                                <div class="mb-3">

                                    <button type="submit" class="btn btn-success">Editar</button>
                                    <a href="../html/indexjefe-usuarios.php" class="btn btn-danger">Cancelar</a>

                                </div>
                            </div>
                        </div>

    </form>
    </div>
    </div>
    </div>
    </div>
    </div>
    </form>
</body>

</html>