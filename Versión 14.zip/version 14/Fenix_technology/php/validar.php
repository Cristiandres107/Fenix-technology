<?php
$conexion = mysqli_connect("localhost", "root", "", "fenix_technology");

if (isset($_POST['registrar'])) {

  if (
    strlen($_POST['PK_fk_Id_tdoc']) >= 1 && strlen($_POST['Numero_documento']) >= 1 && strlen($_POST['Primer_nombre']) >= 1 && strlen($_POST['Segundo_nombre']) >= 1 &&
    strlen($_POST['Primer_apellido']) >= 1 && strlen($_POST['Segundo_apellido']) >= 1 && strlen($_POST['Telefono_contacto']) >= 1 && strlen($_POST['Nombre_usuario']) >= 1 &&
    strlen($_POST['Email']) >= 1 && strlen($_POST['Clave']) >= 1 && strlen($_POST['Estado_usuario']) >= 1
  ) {

    $tdoc = trim($_POST['PK_fk_Id_tdoc']);
    $ndocumento = trim($_POST['Numero_documento']);
    $primer_nombre = trim($_POST['Primer_nombre']);
    $segundo_nombre = trim($_POST['Segundo_nombre']);
    $primer_apellido = trim($_POST['Primer_apellido']);
    $segundo_apellido = trim($_POST['Segundo_apellido']);
    $telefono = trim($_POST['Telefono_contacto']);
    $nombre_usuario = trim($_POST['Nombre_usuario']);
    $email = trim($_POST['Email']);
    $clave = trim($_POST['Clave']);
    $estado = trim($_POST['Estado_usuario']);

    $consulta = "INSERT INTO usuario (PK_fk_Id_tdoc ,Numero_documento ,Primer_nombre ,Segundo_nombre ,Primer_apellido ,Segundo_apellido ,
    Telefono_contacto ,Nombre_usuario ,Email , Clave, Estado_usuario)
    VALUES ('$tdoc','$ndocumento','$primer_nombre', '$segundo_nombre', '$primer_apellido', '$segundo_apellido', '$telefono',
     '$nombre_usuario', '$email', '$clave', '$estado')";

    mysqli_query($conexion, $consulta);
    mysqli_close($conexion);

    header('Location: ../html/indexjefe-usuarios.php');
  }
}









?>