<?php
include_once '../php_productos/conexion.php';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    $buscar_id = $con->prepare('SELECT * FROM producto WHERE Id_producto=:id LIMIT 1');
    $buscar_id->execute(array(
        ':id' => $id
    ));
    $resultado = $buscar_id->fetch();
} else {
    header('Location: index_producto.php');
}

if (isset($_POST['guardar'])) {
    $modelo = $_POST['modelo'];
    $tipo = $_POST['tipo'];
    $color = $_POST['color'];
    $precio = $_POST['precio'];
    $talla_disponible = $_POST['talla_disponible'];
    $cantidad_disponible = $_POST['cantidad_disponible'];
    $id = (int)$_GET['id'];

    if (!empty($modelo) && !empty($tipo) && !empty($color) && !empty($precio) && !empty($talla_disponible) && isset($cantidad_disponible)) {
        if (!filter_var($precio, FILTER_VALIDATE_FLOAT) || $precio < 0) {
            echo "<script> alert('Precio no válido');</script>";
        } elseif (!filter_var($cantidad_disponible, FILTER_VALIDATE_INT) || $cantidad_disponible < 0) {
            echo "<script> alert('Cantidad no válida');</script>";
        } else {
            $consulta_update = $con->prepare(' UPDATE producto SET  
                Modelo_producto=:modelo,
                Tipo_producto=:tipo,
                Color_producto=:color,
                Precio_producto=:precio,
                Talla_disponible_producto=:talla_disponible,
                Cantidad_disponible_producto=:cantidad_disponible
                WHERE Id_producto=:id;'
            );
            $consulta_update->execute(array(
                ':modelo' => $modelo,
                ':tipo' => $tipo,
                ':color' => $color,
                ':precio' => $precio,
                ':talla_disponible' => $talla_disponible,
                ':cantidad_disponible' => $cantidad_disponible,
                ':id' => $id
            ));
            header('Location: ../htmlbodeguero/adidascaballeros.php');
        }
    } else {
        echo "<script> alert('Los campos están vacíos');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Editar Producto</title>
    <link rel="stylesheet" href="../php_productos/csss/estilo.css">
</head>

<body>
    <div class="contenedor">
        <h2>CRUD EN PHP CON MYSQL</h2>
        <form action="" method="post">
            <div class="form-group">
                <input type="text" name="modelo" value="<?php if ($resultado) echo $resultado['Modelo_producto']; ?>" class="input__text">
                <input type="text" name="tipo" value="<?php if ($resultado) echo $resultado['Tipo_producto']; ?>" class="input__text">
            </div>
            <div class="form-group">
                <input type="text" name="color" value="<?php if ($resultado) echo $resultado['Color_producto']; ?>" class="input__text">
                <input type="text" name="precio" value="<?php if ($resultado) echo $resultado['Precio_producto']; ?>" class="input__text">
            </div>
            <div class="form-group">
                <input type="text" name="talla_disponible" value="<?php if ($resultado) echo $resultado['Talla_disponible_producto']; ?>" class="input__text">
                <input type="text" name="cantidad_disponible" value="<?php if ($resultado) echo $resultado['Cantidad_disponible_producto']; ?>" class="input__text">
            </div>
            <div class="btn__group">
                <a href="../htmlbodeguero/adidascaballeros.php" class="btn btn__danger">Cancelar</a>
                <input type="submit" name="guardar" value="Guardar" class="btn btn__primary">
            </div>
        </form>
    </div>
</body>

</html>
