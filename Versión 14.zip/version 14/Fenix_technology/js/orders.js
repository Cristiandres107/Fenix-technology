const Orders = [
    {
        productName: 'Jordan ',
        tipoproduct: 'hombre',
        productnumber: '$150.000',
        tallas: '36,38 y 39',
        color:blanca-roja,
        shipping: 'Pending'
    },
    {
    productName: 'Jordan ',
    tipoproduct: 'dama',
    productnumber: '$140.000',
    tallas: '36,38 y 39',
    color:negra-roja,
    shipping: 'Pending'
    },
    {
    productName: 'nike ',
    tipoproduct: 'hombre',
    productnumber: '160.000',
    tallas: '36,38 y 39',
    color:blanca-roja,
    shipping: 'Pending'
    },
    { productName: 'Adidas ',
    tipoproduct: 'hombre',
    productnumber: '$155.000',
    tallas: '36,38 y 39',
    color:blanca-verde,
    shipping: 'Pending'
    }, 
    {productName: 'Puma ',
    tipoproduct: 'dama',
    productnumber: '$135.000',
    tallas: '36,38 y 39',
    color:negra-roja,
    shipping: 'Pending'
    },
]