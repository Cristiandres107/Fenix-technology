<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Jordan Damas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/inventario.css">
    <link rel="shortcut icon" href="../img/logo.png">
    <style>
      /* Ajusta el margen derecho negativo de las tarjetas */
      .contenedor-tarjetas .fila {
          display: flex;
          flex-wrap: wrap;
          margin-right: -15px;
      }
  
      /* Estilo para ocultar los filtros */
       .ocultar-filtros {
       margin-right: -300px; 
        transition: margin-right 0.3s ease;
      }
       .filtro-columna.ocultar-filtros label,
       .filtro-columna.ocultar-filtros select,
       .filtro-columna.ocultar-filtros input,
       .filtro-columna.ocultar-filtros button {
        display: none;
      }

      /* Ajusta el espacio superior del contenedor principal */
       .container-fluid {
       padding-top: 20px; 
      }

       /* Centra los elementos verticalmente en el contenedor flexible */
       .d-flex {
       align-items: center; 
      }

       /* Ajusta el espacio entre los dos botones */
       #toggleFiltrosButton {
       margin-left: 10px; 
      }

       .ancho-filtro {
       max-width: 7000px; 
      }

       /* Ajusta el ancho de los recuadros desplegables */
       .filtro-columna select {
       width: 150%;
       }

       /* Agrega espacio entre las opciones de los recuadros desplegables */
       .filtro-columna select option {
       margin-bottom: 30px;}
      </style>
</head>

<body>
    <br>
    <ul class="nav nav-pills">
        <li class="nav-item">
          <li class="nav-item custom-margin">
            <a class="nav-link active btn btn-dark" aria-current="page" href="../html/inventariojefebodega.html">Volver atras</a>
        </li>
    <li class="nav-item custom-margin">
      
<!-- Botón para exportar a Excel -->
<button id="export-button" class="btn btn-dark">Exportar a Excel</button>

<!-- Código para la exportación de las zapatillas -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>

<script>
    document.getElementById("export-button").addEventListener("click", function () {
        // Crear un nuevo libro de Excel
        const wb = XLSX.utils.book_new();
        const wsName = "Productos"; // Nombre de la hoja de cálculo

        // Recopilar datos de productos
        const products = [];
        const productRows = document.querySelectorAll("table tr");

        productRows.forEach((productRow, index) => {
            const cells = productRow.querySelectorAll("td");

            if (cells.length > 0) {
                // Agregar el nombre y detalles del producto al array de productos
                const productDetails = [];
                cells.forEach(cell => {
                    productDetails.push(cell.textContent);
                });

                products.push(productDetails);
            }
        });

        // Crear la hoja de cálculo
        const headerRow = Array.from(productRows[0].querySelectorAll("th")).map(cell => cell.textContent);
        const data = [headerRow, ...products];
        const ws = XLSX.utils.aoa_to_sheet(data);
        XLSX.utils.book_append_sheet(wb, ws, wsName);

        // Exportar el libro de Excel a un archivo
        XLSX.writeFile(wb, "productos.xlsx");
    });
</script>
<!-- Fin del código de exportación de las zapatillas a excel -->




<li class="nav-item custom-margin">
<!--  codigo para imprimir y exportar pdf -->
<button id="export-pdf-button" class="btn btn-dark">Exportar a PDF</button>

<!-- Agrega el script para exportar a PDF -->
<script>
document.getElementById("export-pdf-button").addEventListener("click", function () {
    // Ocultar el botón de exportación para que no aparezca en el PDF
    document.getElementById("export-pdf-button").style.display = "none";
    
    // Imprimir la página actual a PDF
    window.print();

    // Volver a mostrar el botón de exportación después de imprimir
    document.getElementById("export-pdf-button").style.display = "block";
});
</script>
<!--  fin para el Código de la exportación a pdf -->



</ul>

<br>
 <!-- Botón para abrir el modal -->
 <button id="toggleFiltrosButton" class="btn btn-primary" onclick="toggleFiltros()">Mostrar/Ocultar Filtros</button>
  <!-- fin del botón para abrir el modal de agregar zapatillas-->

<!-- Contenedor filtros -->
<div class="container-fluid">
  <div class="row">
    <div class="col-md-3 filtro-columna contenedor-filtro mx-auto ancho-filtro">       
    <!-- Columna del filtro -->
  <div class="filtro-columna">
          <!-- Agrega tus filtros aquí -->
          <label for="filtroModelo" class="form-label">Filtrar por Modelo:</label>
          <select id="filtroModelo" class="form-select">
          <!-- Opciones de modelos -->
          <option value="">Todos</option>
          <option value="air Jordan 1 Mid Strawberries Cream">air Jordan 1 Mid Strawberries Cream</option>
          <option value="Deporte Tenis Nike Air Jordan 11 concord Con Manguera AltaBlancoNegro">Deporte Tenis Nike Air Jordan 11 concord Con Manguera AltaBlancoNegro</option>
          <option value="Deporte Tenis Nike Air Jordan
          ">Deporte Tenis Nike Air Jordan
        </option>
          <option value="Jordan 1 Mid SE Bright Citrus Bright CitrusBlanco">Jordan 1 Mid SE Bright Citrus Bright CitrusBlanco</option>
          <option value="Zapatillas para Dama Jordan Retro">Zapatillas para Dama Jordan Retro</option>
          <option value="Nike Jordan 1 Mid Arctic Rosado Pre-School">Nike Jordan 1 Mid Arctic Rosado Pre-School</option>
      </select>
  </div>

      <label for="filtroTipo" class="form-label">Filtrar por Tipo:</label>
      <select id="filtroTipo" class="form-select">
          <!-- Opciones de tipos -->
          <option value="">Todos</option>
          <option value="Deportiva">Deportiva</option>
          <option value="Juvenil">Juvenil</option>
          <option value="clasica">clasica</option>
      </select>

      <label for="filtroColor" class="form-label">Filtrar por Color:</label>
      <select id="filtroColor" class="form-select">
          <!-- Opciones de colores -->
          <option value="">Todos</option>
          <option value="rosadas">rosadas</option>
          <option value="blanco con negro">blanco con negro</option>
          <option value="negro con morado">negro con morado</option>
          <option value="multicolor">multicolor</option>
      </select>
  
      <label for="filtroPrecio" class="form-label">Filtrar por Precio:</label>
      <input type="number" id="filtroPrecio" class="form-control" placeholder="Precio">
 
      <label for="filtroTalla" class="form-label">Filtrar por Talla:</label>
      <select id="filtroTalla" class="form-select">
          <!-- Opciones de tallas -->
          <option value="">Todos</option>
          <option value="30-40">30-40</option>
          <option value="30-47">30-47</option>
      </select>
 
      <label for="filtroCantidad" class="form-label">Filtrar por Cantidad:</label>
      <input type="number" id="filtroCantidad" class="form-control" placeholder="Cantidad">
  <div class="col-md-3">
      <button class="btn btn-primary mt-4" onclick="aplicarFiltros()">Aplicar Filtros</button>
  </div>
</div>
</div>
 <!-- fin del codigo para el filtro-->

<!-- crud para las zapatillas-->
<?php
	include_once '../php_productos/conexion.php';

	$sentencia_select = $con->prepare('SELECT * FROM producto ORDER BY Id_producto DESC');
	$sentencia_select->execute();
	$resultado = $sentencia_select->fetchAll();

	// Metodo buscar
	if (isset($_POST['btn_buscar'])) {
		$buscar_text = $_POST['buscar'];
		$select_buscar = $con->prepare('
			SELECT * FROM producto WHERE Modelo_producto LIKE :campo OR Tipo_producto LIKE :campo;'
		);

		$select_buscar->execute(array(
			':campo' => "%" . $buscar_text . "%"
		));

		$resultado = $select_buscar->fetchAll();
	}

?>

	<link rel="stylesheet" href="../php_productos/csss/estilo.css">
</head>
<body>
	<div class="contenedor">
		<h2> Productos</h2>
		<div class="barra__buscador">
			<form action="" class="formulario" method="post">
				<input type="text" name="buscar" placeholder="buscar modelo o tipo" 
				value="<?php if (isset($buscar_text)) echo $buscar_text; ?>" class="input__text">
				<input type="submit" class="btn" name="btn_buscar" value="Buscar">
				<a href="../php_productos/insert.php" class="btn btn__nuevo">Nuevo Producto</a>
			</form>
		</div>

        <table>
    <tr class="head">
        <td>ID</td>
        <td>Modelo</td>
        <td>Tipo</td>
        <td>Color</td>
        <td>Precio</td>
        <td>Talla Disponible</td>
        <td>Cantidad Disponible</td>
        <td>Acción</td>
    </tr>
    <?php foreach ($resultado as $fila) : ?>
        <tr>
            <td><?php echo $fila['Id_producto']; ?></td>
            <td><?php echo $fila['Modelo_producto']; ?></td>
            <td><?php echo $fila['Tipo_producto']; ?></td>
            <td><?php echo $fila['Color_producto']; ?></td>
            <td><?php echo $fila['Precio_producto']; ?></td>
            <td><?php echo $fila['Talla_disponible_producto']; ?></td>
            <td><?php echo $fila['Cantidad_disponible_producto']; ?></td>
            <td>
                <a href="../php_productos/update.php?id=<?php echo $fila['Id_producto']; ?>" class="btn__update">Editar</a>
                <a href="../php_productos/delete.php?id=<?php echo $fila['Id_producto']; ?>" class="btn__delete">Eliminar</a>
            
            </td>
        </tr>
    <?php endforeach ?>
</table>
	</div>

    <!--fin del codigo del crud para las zapatillas-->



<!-- contenedor de las tarjetas de las zapatillas-->
<br><br>
<div class="col-md-15 contenedor-tarjetas d-flex align-items-center justify-content-center">
    <!-- Columna de las tarjetas -->
    <br>
    <div class="col-md-10">
     <div class="fila">
         <div class="row">
   <!--tarjeta 1-->
   <div class="col-sm-6 mb-3 mb-sm-0">
      <div class="card">
        <div class="card-body">
            <img src="../img/damas/jordan/Air Jordan 1 Mid “Strawberries  Cream”/arriba.jpeg" class="card-img-top" alt="...">
          <h5>213</h5>
          <p class="card-text"></p>
          <a href="../htmldamasbodeguero/jordandama1.html" class="btn btn-primary">ver detalles</a>
        </div>
      </div>
    </div>

  <br>
<!--tarjeta 2-->
    <div class="col-sm-6 mb-3 mb-sm-0">
      <div class="card">
        <div class="card-body">
            <img src="../img/damas/jordan/Deporte Tenis Nike Air Jordan 11 concord Con Manguera AltaBlancoNegro Para Hombres Y Mujeres/lado derecho.jpeg" class="card-img-top" alt="...">
          <h5>214</h5>
          <p class="card-text"></p>
          <a href="../htmldamasbodeguero/jordandama2.html" class="btn btn-primary">ver detalles</a>
        </div>
      </div>
    </div>
 

<br>
<!--tarjeta 3-->
<div class="col-sm-6 mb-3 mb-sm-0">
      <div class="card">
        <div class="card-body">
            <img src="../img/damas/jordan/jordan Nike - Tenis de baloncesto unisex, morado/lado derecho.jpeg" class="card-img-top" alt="...">
       
          <h5>215</h5>
          <p class="card-text"></p>
          <a href="../htmldamasbodeguero/jordandama4.html" class="btn btn-primary">ver detalles</a>
        </div>
      </div>
    </div>


  <br>
  <!--tarjeta 4-->
  <div class="col-sm-6 mb-3 mb-sm-0">
      <div class="card">
        <div class="card-body">
            <img src="../img/damas/jordan/Jordan 1 Mid SE Bright Citrus Bright CitrusBlanco CZ0774 800 para mujerAzul francésEmber mágico 8.5 US/lado derecho.jpeg" class="card-img-top" alt="...">

          <h5>216</h5>
          <p class="card-text"></p>
          <a href="../htmldamasbodeguero/jordandama3.html" class="btn btn-primary">ver detalles</a>
        </div>
      </div>
    </div>
  </div>

<br>
<!--tarjeta 5-->
<div class="col-sm-6 mb-3 mb-sm-0">
      <div class="card">
        <div class="card-body">
            <img src="../img/damas/jordan/Zapatillas para Dama Jordan Retro/lafo izquierdo.jpeg" class="card-img-top" alt="...">
          <h5>217</h5>
          <p class="card-text"></p>
          <a href="../htmldamasbodeguero/jordandama6.html" class="btn btn-primary">ver detalles</a>
        </div>
      </div>
    </div>


<br>
  <!--tarjeta 6-->
  <div class="col-sm-6 mb-3 mb-sm-0">
      <div class="card">
        <div class="card-body">
            <img src="../img/damas/jordan/Nike Jordan 1 Mid Arctic Rosado Pre-School PS/alfrente.jpeg" class="card-img-top" alt="...">
          <h5>218</h5>
          <p class="card-text"></p>
          <a href="../htmldamasbodeguero/jordandama5.html" class="btn btn-primary">ver detalles</a>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</br>
  

<script>
  document.addEventListener("DOMContentLoaded", function () {
      // Código para agregar productos al cargar la página
      actualizarListaProductos();
  });

  // Agregar un evento clic al botón de "Agregar" en el modal
  document.getElementById("addProductButton").addEventListener("click", agregarProducto);
</script>


<!-- Agrega este bloque en tu script JavaScript -->
<script>
  function aplicarFiltros() {
      const filtroModelo = document.getElementById('filtroModelo').value.toLowerCase();
      const filtroTipo = document.getElementById('filtroTipo').value.toLowerCase();
      const filtroColor = document.getElementById('filtroColor').value.toLowerCase();
      const filtroPrecio = parseFloat(document.getElementById('filtroPrecio').value);
      const filtroTalla = document.getElementById('filtroTalla').value.toLowerCase();
      const filtroCantidad = parseInt(document.getElementById('filtroCantidad').value);

      // Aplicar los filtros a las tarjetas
      const tarjetas = document.querySelectorAll('.card');
      tarjetas.forEach(tarjeta => {
          const modelo = tarjeta.querySelector('h4').textContent.toLowerCase();
          const tipo = tarjeta.querySelectorAll('h6')[0].textContent.toLowerCase();
          const color = tarjeta.querySelectorAll('h6')[1].textContent.toLowerCase();
          const precio = parseFloat(tarjeta.querySelectorAll('h6')[2].textContent);
          const talla = tarjeta.querySelectorAll('h6')[3].textContent.toLowerCase();
          const cantidad = parseInt(tarjeta.querySelectorAll('h6')[4].textContent);

          if (
              (filtroModelo === '' || modelo.includes(filtroModelo)) &&
              (filtroTipo === '' || tipo.includes(filtroTipo)) &&
              (filtroColor === '' || color.includes(filtroColor)) &&
              (isNaN(filtroPrecio) || precio <= filtroPrecio) &&
              (filtroTalla === '' || talla.includes(filtroTalla)) &&
              (isNaN(filtroCantidad) || cantidad <= filtroCantidad)
          ) {
              tarjeta.style.display = 'block';
          } else {
              tarjeta.style.display = 'none';
          }
      });
  }


 // Agrega este bloque en tu script JavaScript
 document.addEventListener("DOMContentLoaded", function () {
  // Al cargar la página, oculta los filtros
  toggleFiltros();
});

function toggleFiltros() {
  const contenedorFiltros = document.querySelector('.contenedor-filtro');
  const contenedorTarjetas = document.querySelector('.contenedor-tarjetas');

  // Cambia las clases para mostrar u ocultar los filtros
  contenedorFiltros.classList.toggle('ocultar-filtros');
  contenedorTarjetas.classList.toggle('contenedor-tarjetas-extendido'); // Ajusta el ancho si es necesario

  // Cambia el texto del botón
  const toggleFiltrosButton = document.getElementById('toggleFiltrosButton');
  if (contenedorFiltros.classList.contains('ocultar-filtros')) {
      toggleFiltrosButton.textContent = 'Mostrar Filtros';
  } else {
      toggleFiltrosButton.textContent = 'Ocultar Filtros';
  }
}
</script>




<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="../js/inventario.js" ></script>
</body>
</html>