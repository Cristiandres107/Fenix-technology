<?php
include('../php/conexion.php');
$conexion = conexion();

$sql = "SELECT * FROM usuario";
$query = mysqli_query($conexion, $sql);

$row = mysqli_fetch_array($query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index_jefe</title>
    <!--MATERIAL ICONS-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <!--ESTILOS CSS-->
    <link rel="stylesheet" href="../css/indexjefe.css">
    <link rel="shortcut icon" href="/img/logo.png">
</head>

<body>


    <div class="container">
        <aside>
            <div class="top">
                <div class="logo">
                    <img src="../img/logo.png" alt="">
                    <h2 class="text-muted">Sport <span class="danger">Line</span></h2>
                    <div class="close" id="close-btn">
                        <span class="material-icons-sharp">close</span>
                    </div>
                </div>
            </div>
            <div class="sidebar">
                <a href="#">
                    <span class="material-icons-sharp">grid_view</span>
                    <h3>Menu</h3>
                </a>
                <a href="#" class="active">
                    <span class="material-icons-sharp">person_outline</span>
                    <h3>Usuarios</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">receipt_long</span>
                    <h3>Pedidos</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">insights</span>
                    <h3>Estadísticas</h3>
                </a>
                <a href="/html/indexjefe.html" id="liveToastBtn">
                    <span class="material-icons-sharp">mail_outline</span>
                    <h3 id="liveToastBtn">Mensajes</h3>
                    <span class="message-count">100</span>
                </a>
                <a href="../html/inventariojefeprincipal.html">
                    <span class="material-icons-sharp">inventory</span>
                    <h3>Productos</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">report_gmailerrorred</span>
                    <h3>Reportes</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">settings</span>
                    <h3>Configuración</h3>
                </a>
                <a href="../html/index.html">
                    <span class="material-icons-sharp">logout</span>
                    <h3>Cerrar sesión</h3>
                </a>
            </div>
        </aside>
        <!-- FINALIZA LA SECCIÓN DE ASIDE-->
        <main>
            <h1>Usuarios</h1>

            <div class="date">
                <input type="date">
            </div>

            <div class="recent-orders">
                <h2>Usuarios registrados</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Id usuario</th>
                            <th>Id Tdoc</th>
                            <th>Número de documento</th>
                            <th>Primer nombre</th>
                            <th>Segundo nombre</th>
                            <th>Primer apellido</th>
                            <th>Segundo apellido</th>
                            <th>Teléfono contacto</th>
                            <th>Nombre usuario</th>
                            <th>Email</th>
                            <th>Clave</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while ($row = mysqli_fetch_array($query)): ?>
                            <tr>
                                <th>
                                    <?php echo $row['Id_usuario'] ?>
                                </th>
                                <th>
                                    <?php echo $row['PK_fk_Id_tdoc'] ?>
                                </th>
                                <th>
                                    <?php echo $row['Numero_documento'] ?>
                                </th>
                                <th>
                                    <?php echo $row['Primer_nombre'] ?>
                                </th>
                                <th>
                                    <?php echo $row['Segundo_nombre'] ?>
                                </th>
                                <th>
                                    <?php echo $row['Primer_apellido'] ?>
                                </th>
                                <th>
                                    <?php echo $row['Segundo_apellido'] ?>
                                </th>
                                <th>
                                    <?php echo $row['Telefono_contacto'] ?>
                                </th>
                                <th>
                                    <?php echo $row['Nombre_usuario'] ?>
                                </th>
                                <th>
                                    <?php echo $row['Email'] ?>
                                </th>
                                <th>
                                    <?php echo $row['Clave'] ?>
                                </th>
                                <th>
                                    <?php echo $row['Estado_usuario'] ?>
                                </th>
                                <th><a href="actualizar.php?Numero_documento=<?php echo $row['Numero_documento'] ?>"
                                        class="warning">Editar</a></th>
                                <th><a href="eliminar.php?Numero_documento=<?php echo $row['Numero_documento'] ?>"
                                        class="primary">Eliminar</a></th>
                            </tr>
                            <?php
                        endwhile;
                        ?>
                        <tr>
                            <td>Adi2000</td>
                            <td>Adidas</td>
                            <td>Unisex</td>
                            <td>36-42</td>
                            <td>Blanca-negro</td>
                            <td>$150.000</td>
                            <td class="warning">Pendiente</td>
                            <td class="primary">Detalles</td>
                        </tr>
                    </tbody>
                </table>
                <a href="#">Mostrar todo</a>
            </div>
        </main>
        <!--FINALIZA MAIN-->

        <script src="../js/indexjefe.js"></script>
        <script src="../js/orders.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
            crossorigin="anonymous"></script>
</body>

</html>