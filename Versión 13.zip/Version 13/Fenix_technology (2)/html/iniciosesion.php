<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Iniciar Sesión </title>
  <link rel="stylesheet" href="../css/estilosprueba.css">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <!-- Bootstrap CSS -->
  <link rel="shortcut icon" href="/img/logo.png">

</head>

<body>
  <a href="index.html" class="home-link">
    <button class="home-button">
      <i class='bx bx-home'></i> Volver a Inicio
    </button>
  </a>


  <div class="wrapper">
    <form action="../php/funciones.php" method="POST">
      <h1>Iniciar Sesión </h1>
      <div class="input-box">
        <input type="text" id="Nombre_usuario" name="Nombre_usuario" placeholder="Nombre" required>
        <i class='bx bxs-user'></i>
      </div>
      <div class="input-box">
        <input type="password" id="Clave" name="Clave" placeholder="Contraseña" required>
        <input type="hidden" name="accion" value="acceso_user">
        <i class='bx bxs-lock-alt'></i>
      </div>
      <div class="remember-forgot">
        <label><input type="checkbox">Recordarme</label>
        <a href="recuperarcontraseña.html">¿Olvidé mi contraseña?</a>
      </div>
      <input type="submit" class="btn" value="Iniciar sesión">
    </form>
  </div>

  </div>

</body>

</html>