<?php

session_start();
error_reporting(0);

$validar = $_SESSION['Nombre_usuario'];

if ($validar == null || $validar = '') {

    header("Location: iniciosesion.php");
    die();

}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios</title>
    <!--MATERIAL ICONS-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <!--ESTILOS CSS-->
    <link rel="stylesheet" href="../css/indexjefe.css">
    <link rel="shortcut icon" href="/img/logo.png">
</head>

<body>


    <div class="container">
        <aside>
            <div class="top">
                <div class="logo">
                    <img src="../img/logo.png" alt="">
                    <h2 class="text-muted">Sport <span class="danger">Line</span></h2>
                    <div class="close" id="close-btn">
                        <span class="material-icons-sharp">close</span>
                    </div>
                </div>
            </div>
            <div class="sidebar">
                <a href="#">
                    <span class="material-icons-sharp">grid_view</span>
                    <h3>Menu</h3>
                </a>
                <a href="#" class="active">
                    <span class="material-icons-sharp">person_outline</span>
                    <h3>Usuarios</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">receipt_long</span>
                    <h3>Pedidos</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">insights</span>
                    <h3>Estadísticas</h3>
                </a>
                <a href="/html/indexjefe.html" id="liveToastBtn">
                    <span class="material-icons-sharp">mail_outline</span>
                    <h3 id="liveToastBtn">Mensajes</h3>
                    <span class="message-count">100</span>
                </a>
                <a href="../html/inventariojefeprincipal.html">
                    <span class="material-icons-sharp">inventory</span>
                    <h3>Productos</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">report_gmailerrorred</span>
                    <h3>Reportes</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">settings</span>
                    <h3>Configuración</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">add</span>
                    <h3>Añadir producto</h3>
                </a>
                <a href="../php/cerrarSesion.php">
                    <span class="material-icons-sharp">logout</span>
                    <h3>Cerrar sesión</h3>
                </a>
            </div>
        </aside>
        <!-- FINALIZA LA SECCIÓN DE ASIDE-->
        <main>

            <h1>Bienvenido Administrador
                <?php echo $_SESSION['Primer_nombre']; ?>
            </h1>
            <div class="date">
                <input type="date">
            </div>


            <div class="recent-orders">
                <h1>Usuarios</h1>
                <br>
                <div>
                    <a class="btn btn-success" href="../php/registro.php">Nuevo usuario
                        <i class="fa fa-plus"></i> </a>
                    <a class="btn btn-warning" href="../php/cerrarSesion.php">Cerrar Sesion
                        <i class="fa fa-power-off" aria-hidden="true"></i>
                    </a>

                </div>
                <br>
                <table class="table table-striped table-dark " id="table_id">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Tipo_documento</th>
                            <th>Numero_documento</th>
                            <th>Primer_nombre</th>
                            <th>Segundo_nombre</th>
                            <th>Primer_apellido</th>
                            <th>Segundo_apellido</th>
                            <th>Telefono_contacto</th>
                            <th>Nombre_usuario</th>
                            <th>Email</th>
                            <th>Clave</th>
                            <th>Estado_usuario</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php

                        $conexion = mysqli_connect("localhost", "root", "", "fenix_technology");
                        $SQL = "SELECT usuario.Id_usuario, usuario.PK_fk_Id_tdoc, usuario.Numero_documento, usuario.Primer_nombre, usuario.Segundo_nombre,
usuario.Primer_apellido,,usuario.Segundo_apellido, usuario.Telefono_contacto, usuario.Nombre_usuario, usuario.Email, usuario.Clave, usuario.Estado_usuario FROM usuario";
                        $dato = mysqli_query($conexion, $SQL);

                        if ($dato->num_rows > 0) {
                            while ($fila = mysqli_fetch_array($dato)) {

                                ?>
                                <tr>
                                    <td>
                                        <?php echo $fila['Id_usuario']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['PK_fk_Id_tdoc']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['Numero_documento']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['Primer_nombre']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['Segundo_nombre']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['Primer_apellido']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['Segundo_apellido']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['Telefono_contacto']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['Nombre_usuario']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['Email']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['Clave']; ?>
                                    </td>
                                    <td>
                                        <?php echo $fila['Estado_usuario']; ?>
                                    </td>




                                    <td>


                                        <a class="primary" href="../php/actualizar.php?id=<?php echo $fila['Id_usuario'] ?> ">
                                            <i class="fa fa-edit">Editar</i></a>

                                        <a class="warning" href="../php/eliminar.php?id=<?php echo $fila['Id_usuario'] ?>">
                                            <i class="fa fa-trash">Eliminar</i></a>

                                    </td>
                                </tr>


                                <?php
                            }
                        } else {

                            ?>
                            <tr class="text-center">
                                <td colspan="16">No existen registros</td>
                            </tr>


                            <?php

                        }

                        ?>

</html>
</tbody>
</table>
</div>
</main>
<!--FINALIZA MAIN-->

<script src="../js/indexjefe.js"></script>
<script src="../js/orders.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
    crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anony
                       mous"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
<script src="../js/user.js"></script>
</body>

</html>