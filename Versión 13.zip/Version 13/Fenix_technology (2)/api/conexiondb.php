<?php

class DB
{
    private $host;
    private $db;
    private $user;
    private $password;
    private $charset;

    public function __construct()
    {
        $this->host = 'localhost';
        $this->db = 'fenix_technology';
        $this->user = 'root';
        $this->password = '';
        $this->charset = 'utf8mb4';
    }

    function conexion()
    {

        try {

            $conexion = "mysql:host".this->host.";dbname=".$this->db.
        }
    }
}
?>