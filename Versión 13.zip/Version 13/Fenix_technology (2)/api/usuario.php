<?php
include_once 'conexiondb.php';

class usuario extends DB{
    function obtenerUsuarios(){
      $query = $this-> conexion()->query('SELECT * FROM usuario'); 
      return $query;
    }
}
?>