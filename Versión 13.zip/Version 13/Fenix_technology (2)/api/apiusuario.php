<?php

include_once 'usuario.php';

class Apiusuarios{

    function getAll(){
        $usuario = new Usuario();
        $usuarios = array();
        $usuarios["items"] = array();

        $res = $usuario->obtenerUsuarios();
        

        
        if($res->rowcount()){
            while($row = $res-> fecth(PDO::FETCH_ASSOC)){
                $item = array(
                    'id_usuario'=>$row["id_usuario"],
                    'tdoc'=>$row["PK_fk_Id_tdoc"],
                    'numero_documento'=>$row["Numero_documento"],
                    'Primer_nombre'=>$row["Primer_nombre"],
                    'Segundo_nombre'=>$row["Segundo_nombre"],
                    'Primer_apellido'=>$row["Primer_apellido"],
                    'Segundo_apellido'=>$row["Segundo_apellido"],
                    'Telefono_contacto'=>$row["Telefono_contacto"],
                    'Nombre_usuario'=>$row["Nombre_usuario"],
                    'Email'=>$row["Email"],
                    'Clave'=>$row["Clave"],
                    'Estado'=>$row["Estado"]
                    
                );
                array_push($usuarios["items"], $item);
            }

            echo json_encode($usuarios);
        }else{
            echo json_encode(array('mensaje'=> 'No hay elementos registrados'));
        } 
    } 

}


?>